package com.service;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Claimbean;
import com.dao.ClaimDao;

public class SaveQuestions extends HttpServlet{
	Statement stmt=null;
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	Claimbean cbean=new Claimbean();
	ClaimDao obj1=new ClaimDao();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//String st1=request.getParameter()
}}
