package com.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CreateClaimAdmin extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		RequestDispatcher rd=null;
		PrintWriter out=res.getWriter();
		String no=req.getParameter("user1");
		HttpSession session5=req.getSession(true);
		session5.setAttribute("un", no);

		rd=req.getRequestDispatcher("/claimcreate.jsp");
		
		rd.forward(req, res);
}}
