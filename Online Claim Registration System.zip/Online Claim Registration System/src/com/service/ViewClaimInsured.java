package com.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ViewClaimInsured extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String num=request.getParameter("cno");
		int n2=Integer.parseInt(num);
		
		HttpSession session7=request.getSession();
		session7.setAttribute("number", n2);
		RequestDispatcher rd=null;
		rd=request.getRequestDispatcher("/viewclaim2.jsp");
		rd.forward(request, response);

		
}
}