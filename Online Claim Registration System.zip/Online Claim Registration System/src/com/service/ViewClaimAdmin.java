package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.Commonconnection;

public class ViewClaimAdmin extends HttpServlet {
public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

	
	Connection con=null;
	 con=Commonconnection.getCon();
	String s=null;
			String s1=null;
	PreparedStatement ps= null;
		RequestDispatcher rd=null;
		PrintWriter out=res.getWriter();
		String no=req.getParameter("user1");
		System.out.println(no);
		ResultSet rs=null;
		HttpSession session5=req.getSession();
		session5.setAttribute("un", no);
		
		rd=req.getRequestDispatcher("/viewclaim.jsp");
		
		rd.forward(req, res);
		
		//System.out.println(um);
		
				
			
			
				/*
				rd=req.getRequestDispatcher("/viewclaimadmin.jsp");
				
				rd.forward(req, res);*/
				
			
		}}