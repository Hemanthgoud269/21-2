package com.claim;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.CommonConnection.Commonconnection;
import com.dao.QueryMapper;

public class Createclaim extends HttpServlet {
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 c=Commonconnection.getCon();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String st1=request.getParameter("claim reason");
		String st2=request.getParameter("accident location");
		String st3=request.getParameter("accident city");
		String st4=request.getParameter("accident state");
		String st5=request.getParameter("accident zip");
        int zip=Integer.parseInt(st5);
        String st6=request.getParameter("claimtype");
        ps=c.prepareStatement(QueryMapper.INSERT_QUERY);
        ps.setString(1, st1);
        ps.setString(2, st2);
        ps.setString(3, st3);
        ps.setString(4, st4);
        ps.setInt(5, zip);
        ps.setString(6, st6);
    ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
}
